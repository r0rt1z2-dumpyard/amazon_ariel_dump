#!/bin/bash
# set up trapz to capture specified components, while you interact with the device

trapzdir="${TRAPZ_DIR:?"export this var for directory with trapztool.py"}"
trapztool="$trapzdir/trapztool.py"
original_pythonpath=$PYTHONPATH
export PYTHONPATH="$trapzdir:$PYTHONPATH"

tmpfile="${TRAPZ_LOG_DIR:-/tmp}/trapz-interactive.xml"
vcd_file="${TRAPZ_LOG_DIR:-/tmp}/trapz-interactive.vcd"

echo You should already enabled some log capture, e.g. by: trapztool.py filter HardwareComposer info

# clear the trapz buffers
read -p "press enter to start trapz log capture: "
adb shell trapz -c
echo CAPTURING......

read -p "press enter to stop trapz log capture: "

adb shell trapz -x > $tmpfile

"$(dirname "$0")/check_hwc.py" $tmpfile

$trapztool vcd --no-tids $tmpfile $vcd_file

# restore
export PYTHONPATH="$original_pythonpath"
